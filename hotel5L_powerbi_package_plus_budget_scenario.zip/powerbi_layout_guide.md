# Power BI — Report Ready (Hotel 5★ Lusso)
Pagine: **Executive**, **F&B & Costing**, **Clienti & Mix**.
1) Importa Excel, crea relazioni, marca `dim_data` come tabella date.
2) Importa il tema `powerbi_theme_hotel5L.json`.
3) Crea su `dim_cliente`: `Età` e `Range Età` (vedi guida nel canvas).
4) Incolla le misure dal file DAX o usa Tabular Editor con lo script .csx.
5) Segui la mappa visual indicata (Executive → KPI/Trend/Treemap; F&B → F&B per Pax/Food Cost%/Complimentary-ON/Attese-ON; Clienti → Nazionalità/Range Età).